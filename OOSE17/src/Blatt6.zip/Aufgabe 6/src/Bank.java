
public class Bank {

	java.util.ArrayList<Konto> Konten = new java.util.ArrayList<>();
	
	public Bank(){
				
	}
	
	void create_konto(String b, int n, double stand){
		
		Konto x = new Konto(b, n, stand);
		
		Konten.add(x);
		
	}
	
	void transfer(String b, int n, double stand){
		
		Konto t = new Konto(b, n, stand);
		
		for(int i=0;i<Konten.size();i++)
		{
			if(Konten.get(i) == t ){
				
				Bank x = new Bank();
				x.Konten.add(t);
				this.Konten.remove(i);
				return;
			} 
			
		}
		
	}
	
	double gesamt(){
		double ges=0;
		
		for(int i=0;i<Konten.size();i++){
			
			Konto x = Konten.get(i);
			ges += x.stnd;
			
		}
		
		return ges;
	}
	
}
