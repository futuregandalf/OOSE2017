

public class TestTrace {
	
public static void main(String[] args) {
	
CallEg eg = new CallEg(); // use default constructor

try {
	
eg.methodA();

} 

catch (ArithmeticException oops) {
oops.printStackTrace();

}
}
}



// a) Ausgabe:  java.lang.ArithmeticException: / by zero
//        	    at CallEg.methodA(CallEg.java:5)
//    	 		at TestTrace.main(TestTrace.java:11)

// b) Ausgabe:  java.lang.ArithmeticException: / by zero
//				at CallEg.methodC(CallEg.java:7)
//				at CallEg.methodB(CallEg.java:6)
//				at CallEg.methodA(CallEg.java:5)
//				at TestTrace.main(TestTrace.java:11)

// c) Ausgabe: java.lang.ArithmeticException: / by zero    	
//				at CallEg.methodC(CallEg.java:34)	-	erster Befund bei der Division selbst
//				at CallEg.methodB(CallEg.java:20)	-	Danach in der indirekten Ausf�hrung in B
//				at CallEg.methodA(CallEg.java:8)	-	Die eigentlich aufgerufene Methode A wird zum Schluss gefangen
//				at TestTrace.main(TestTrace.java:11)