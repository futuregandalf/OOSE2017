import java.util.ArrayList;
import java.util.List;

public class Konto{
	
	double stnd;
	int nr;
	String bes;
	
	List<String> auszug = new ArrayList<String>(); //protokoll f�r den Kontoauszug

	
	
	public Konto(String b, int n, double stand) {
		
		bes = b;
		nr = n;
		stnd = stand;
		
	}

	void einzahlung(double in){
		
		stnd += in;
		auszug.add(in+"� eingezahlt.\n");
		auszug.add("Kontostand: "+stnd+"\n");		//Kontostand wird nach jeder operation aktualisiert
	}
	
	void auszahlung(double out){
		
		if (out > stnd) {System.out.println("Konto nicht ausreichend gedeckt."); return;}		//sicherung f�r genug verm�gen
		stnd -= out;
		auszug.add(out+"� abgehoben.\n");
		auszug.add("Kontostand: "+stnd+"\n");
		
	}
	
	void auszug(){
		
		System.out.println(auszug);
		auszug.clear();								//auszug wird resettet nach ausdruck
	}
	
	public static void main(String[] args) {
		
		Konto a = new Konto("Tom Taler", 3014092, 5000.0);
		a.einzahlung(400.);
		a.auszahlung(10000);
		a.auszug();
		
	
	}

}
